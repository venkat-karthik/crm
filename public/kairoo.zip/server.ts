import express, { Request, Response } from 'express';
import fs from 'fs';
import path from 'path';
import crypto from 'crypto';

const app = express();
const PORT = Number(process.env.PORT) || 3000;

app.use(express.json());

// Persistent database file
const DATA_DIR = path.resolve(process.cwd(), 'data');
const DB_FILE = path.join(DATA_DIR, 'db.json');

if (!fs.existsSync(DATA_DIR)) {
  fs.mkdirSync(DATA_DIR, { recursive: true });
}

// Initial DB Schema
interface DatabaseSchema {
  users: any[];
  customers: any[];
  leads: any[];
  deals: any[];
  tasks: any[];
  calls: any[];
  communications: any[];
  appointments: any[];
  tickets: any[];
  ticket_messages: any[];
  notifications: any[];
  activity_logs: any[];
}

function loadDB(): DatabaseSchema {
  if (!fs.existsSync(DB_FILE)) {
    const initialData: DatabaseSchema = {
      users: [
        {
          id: 'usr_admin_1',
          name: 'Rahul Sharma',
          email: 'admin@kairoo.com',
          passwordHash: hashPassword('admin123'),
          role: 'Admin',
          department: 'Executive',
          status: 'Active',
          createdAt: new Date().toISOString(),
        },
      ],
      customers: [],
      leads: [],
      deals: [],
      tasks: [],
      calls: [],
      communications: [],
      appointments: [],
      tickets: [],
      ticket_messages: [],
      notifications: [],
      activity_logs: [],
    };
    fs.writeFileSync(DB_FILE, JSON.stringify(initialData, null, 2), 'utf-8');
    return initialData;
  }
  try {
    const raw = fs.readFileSync(DB_FILE, 'utf-8');
    return JSON.parse(raw);
  } catch (err) {
    console.error('Failed to read db.json, returning empty template', err);
    return {
      users: [],
      customers: [],
      leads: [],
      deals: [],
      tasks: [],
      calls: [],
      communications: [],
      appointments: [],
      tickets: [],
      ticket_messages: [],
      notifications: [],
      activity_logs: [],
    };
  }
}

function saveDB(data: DatabaseSchema) {
  fs.writeFileSync(DB_FILE, JSON.stringify(data, null, 2), 'utf-8');
}

function hashPassword(pwd: string): string {
  return crypto.createHash('sha256').update(pwd + 'kairoo_secret_salt_2026').digest('hex');
}

function generateId(prefix: string): string {
  return `${prefix}_${Date.now()}_${Math.random().toString(36).substr(2, 6)}`;
}

// --- AUTH ROUTES ---
app.post('/api/auth/signup', (req: Request, res: Response) => {
  const { name, email, password, confirmPassword, company, role = 'Sales Employee' } = req.body;
  if (!name || !email || !password) {
    return res.status(400).json({ error: 'Name, email, and password are required.' });
  }
  if (confirmPassword && password !== confirmPassword) {
    return res.status(400).json({ error: 'Passwords do not match.' });
  }

  const db = loadDB();
  const existing = db.users.find((u) => u.email.toLowerCase() === email.toLowerCase());
  if (existing) {
    return res.status(400).json({ error: 'A user with this email already exists.' });
  }

  const newUser = {
    id: generateId('usr'),
    name,
    email: email.toLowerCase(),
    passwordHash: hashPassword(password),
    company: company || 'Kairoo Enterprise',
    role: db.users.length === 0 ? 'Admin' : role,
    status: 'Active',
    createdAt: new Date().toISOString(),
  };

  db.users.push(newUser);

  // Initial notification
  db.notifications.push({
    id: generateId('notif'),
    userId: newUser.id,
    type: 'Account Created',
    title: 'Welcome to Kairoo CRM',
    message: `Account created successfully with role ${newUser.role}.`,
    isRead: false,
    createdAt: new Date().toISOString(),
  });

  saveDB(db);

  const { passwordHash, ...userSafe } = newUser;
  return res.status(201).json({ user: userSafe, token: `token_${newUser.id}_${Date.now()}` });
});

app.post('/api/auth/login', (req: Request, res: Response) => {
  const { email, password } = req.body;
  if (!email || !password) {
    return res.status(400).json({ error: 'Email and password are required.' });
  }

  const db = loadDB();
  const user = db.users.find(
    (u) => u.email.toLowerCase() === email.toLowerCase() && u.passwordHash === hashPassword(password)
  );

  if (!user) {
    return res.status(401).json({ error: 'Invalid email or password.' });
  }

  if (user.status === 'Disabled') {
    return res.status(403).json({ error: 'Your account has been deactivated by an Administrator.' });
  }

  const { passwordHash, ...userSafe } = user;
  return res.json({ user: userSafe, token: `token_${user.id}_${Date.now()}` });
});

app.post('/api/auth/forgot-password', (req: Request, res: Response) => {
  const { email } = req.body;
  if (!email) return res.status(400).json({ error: 'Email is required.' });

  const db = loadDB();
  const user = db.users.find((u) => u.email.toLowerCase() === email.toLowerCase());
  if (!user) {
    return res.status(404).json({ error: 'No account found with this email address.' });
  }

  return res.json({ message: 'Password recovery email sent. Please check your inbox for instructions.' });
});

app.get('/api/auth/me', (req: Request, res: Response) => {
  const authHeader = req.headers.authorization;
  if (!authHeader) return res.status(401).json({ error: 'Unauthorized' });

  const token = authHeader.replace('Bearer ', '');
  const parts = token.split('_');
  const userId = parts[1];

  const db = loadDB();
  const user = db.users.find((u) => u.id === userId);
  if (!user) return res.status(401).json({ error: 'User not found' });

  const { passwordHash, ...userSafe } = user;
  return res.json({ user: userSafe });
});

// --- GENERIC ENTITY HELPER BUILDER ---
function registerCrud(
  collectionName: keyof DatabaseSchema,
  prefix: string,
  onAfterCreate?: (item: any, db: DatabaseSchema) => void
) {
  app.get(`/api/${collectionName}`, (req: Request, res: Response) => {
    const db = loadDB();
    const items = db[collectionName] || [];
    return res.json(items);
  });

  app.post(`/api/${collectionName}`, (req: Request, res: Response) => {
    const db = loadDB();
    const now = new Date().toISOString();
    const newItem = {
      ...req.body,
      id: req.body.id || generateId(prefix),
      createdAt: now,
      updatedAt: now,
    };

    (db[collectionName] as any[]).push(newItem);

    // Activity log
    db.activity_logs.unshift({
      id: generateId('act'),
      entityType: collectionName,
      entityId: newItem.id,
      action: 'Created',
      description: `Created new ${collectionName.slice(0, -1)}: ${newItem.name || newItem.title || newItem.subject || newItem.id}`,
      createdAt: now,
    });

    if (onAfterCreate) {
      onAfterCreate(newItem, db);
    }

    saveDB(db);
    return res.status(201).json(newItem);
  });

  app.put(`/api/${collectionName}/:id`, (req: Request, res: Response) => {
    const db = loadDB();
    const list = db[collectionName] as any[];
    const idx = list.findIndex((item) => item.id === req.params.id);

    if (idx === -1) {
      return res.status(404).json({ error: `${collectionName} record not found` });
    }

    const updated = {
      ...list[idx],
      ...req.body,
      id: list[idx].id,
      updatedAt: new Date().toISOString(),
    };

    list[idx] = updated;

    db.activity_logs.unshift({
      id: generateId('act'),
      entityType: collectionName,
      entityId: updated.id,
      action: 'Updated',
      description: `Updated ${collectionName.slice(0, -1)}: ${updated.name || updated.title || updated.subject || updated.id}`,
      createdAt: new Date().toISOString(),
    });

    saveDB(db);
    return res.json(updated);
  });

  app.delete(`/api/${collectionName}/:id`, (req: Request, res: Response) => {
    const db = loadDB();
    const list = db[collectionName] as any[];
    const idx = list.findIndex((item) => item.id === req.params.id);

    if (idx === -1) {
      return res.status(404).json({ error: `${collectionName} record not found` });
    }

    const removed = list.splice(idx, 1)[0];

    db.activity_logs.unshift({
      id: generateId('act'),
      entityType: collectionName,
      entityId: removed.id,
      action: 'Deleted',
      description: `Deleted ${collectionName.slice(0, -1)}: ${removed.name || removed.title || removed.subject || removed.id}`,
      createdAt: new Date().toISOString(),
    });

    saveDB(db);
    return res.json({ success: true, removed });
  });
}

// Register CRUD for all 10 core entities
registerCrud('customers', 'cust');
registerCrud('leads', 'lead', (newLead, db) => {
  db.notifications.push({
    id: generateId('notif'),
    type: 'New Lead',
    title: 'New Lead Captured',
    message: `${newLead.name} (${newLead.company || 'Website Inbound'}) captured.`,
    isRead: false,
    createdAt: new Date().toISOString(),
  });
});
registerCrud('deals', 'deal');
registerCrud('tasks', 'task');
registerCrud('calls', 'call');
registerCrud('communications', 'comm');
registerCrud('appointments', 'apt');
registerCrud('tickets', 'tkt', (newTicket, db) => {
  db.notifications.push({
    id: generateId('notif'),
    type: 'New Ticket',
    title: 'Support Ticket Created',
    message: `Ticket ${newTicket.id} - ${newTicket.subject}`,
    isRead: false,
    createdAt: new Date().toISOString(),
  });
});
registerCrud('ticket_messages', 'tmsg');
registerCrud('notifications', 'notif');
registerCrud('users', 'usr');

// Special endpoint: mark notifications read
app.post('/api/notifications/mark-all-read', (req: Request, res: Response) => {
  const db = loadDB();
  db.notifications.forEach((n) => {
    n.isRead = true;
  });
  saveDB(db);
  return res.json({ success: true });
});

// Special endpoint: Global Search across customers, leads, deals, tickets, tasks
app.get('/api/search', (req: Request, res: Response) => {
  const query = (req.query.q as string || '').toLowerCase().trim();
  if (!query) return res.json([]);

  const db = loadDB();
  const results: any[] = [];

  db.customers.forEach((c) => {
    if (
      (c.name && c.name.toLowerCase().includes(query)) ||
      (c.email && c.email.toLowerCase().includes(query)) ||
      (c.company && c.company.toLowerCase().includes(query))
    ) {
      results.push({ type: 'Customer', id: c.id, title: c.name, subtitle: c.company || c.email, route: '/customers' });
    }
  });

  db.leads.forEach((l) => {
    if (
      (l.name && l.name.toLowerCase().includes(query)) ||
      (l.email && l.email.toLowerCase().includes(query)) ||
      (l.company && l.company.toLowerCase().includes(query))
    ) {
      results.push({ type: 'Lead', id: l.id, title: l.name, subtitle: `${l.status} · ${l.company || ''}`, route: '/leads' });
    }
  });

  db.deals.forEach((d) => {
    if (
      (d.name && d.name.toLowerCase().includes(query)) ||
      (d.company && d.company.toLowerCase().includes(query))
    ) {
      results.push({ type: 'Deal', id: d.id, title: d.name, subtitle: `${d.stage} · ₹${d.value || 0}`, route: '/pipeline' });
    }
  });

  db.tickets.forEach((t) => {
    if (
      (t.subject && t.subject.toLowerCase().includes(query)) ||
      (t.id && t.id.toLowerCase().includes(query))
    ) {
      results.push({ type: 'Ticket', id: t.id, title: t.subject, subtitle: `${t.id} · ${t.status}`, route: '/tickets' });
    }
  });

  db.tasks.forEach((tsk) => {
    if (tsk.title && tsk.title.toLowerCase().includes(query)) {
      results.push({ type: 'Task', id: tsk.id, title: tsk.title, subtitle: `${tsk.priority} · ${tsk.status}`, route: '/tasks' });
    }
  });

  return res.json(results.slice(0, 15));
});

// Activity logs
app.get('/api/activity_logs', (req: Request, res: Response) => {
  const db = loadDB();
  return res.json((db.activity_logs || []).slice(0, 30));
});

// Calculated Real-Time Metrics & Reports
app.get('/api/reports/summary', (req: Request, res: Response) => {
  const db = loadDB();
  const totalCustomers = db.customers.length;
  const totalLeads = db.leads.length;
  const totalDeals = db.deals.length;
  const wonDeals = db.deals.filter((d) => d.stage === 'Won');
  const lostDeals = db.deals.filter((d) => d.stage === 'Lost');
  const openDeals = db.deals.filter((d) => d.stage !== 'Won' && d.stage !== 'Lost');
  const totalRevenue = wonDeals.reduce((sum, d) => sum + (Number(d.value) || 0), 0);
  const pipelineValue = openDeals.reduce((sum, d) => sum + (Number(d.value) || 0), 0);
  const conversionRate = totalLeads > 0 ? ((wonDeals.length / totalLeads) * 100).toFixed(1) : '0';
  const openTickets = db.tickets.filter((t) => t.status !== 'Closed' && t.status !== 'Resolved').length;
  const pendingTasks = db.tasks.filter((t) => t.status !== 'Completed').length;

  return res.json({
    totalCustomers,
    totalLeads,
    totalDeals,
    wonDealsCount: wonDeals.length,
    lostDealsCount: lostDeals.length,
    openDealsCount: openDeals.length,
    totalRevenue,
    pipelineValue,
    conversionRate: Number(conversionRate),
    openTickets,
    pendingTasks,
  });
});

// Download complete project archive
app.get('/api/download/kairoo-zip', (req: Request, res: Response) => {
  const zipPath = path.join(process.cwd(), 'public', 'kairoo.zip');
  if (fs.existsSync(zipPath)) {
    return res.download(zipPath, 'kairoo.zip');
  }
  return res.status(404).json({ error: 'Archive not found' });
});

// Vite middleware in dev or static files in production
export async function startServer() {
  if (process.env.NODE_ENV !== 'production') {
    const { createServer: createViteServer } = await import('vite');
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.resolve(process.cwd(), 'dist');
    app.use(express.static(distPath));
    app.get('*', (req, res) => {
      res.sendFile(path.join(distPath, 'index.html'));
    });
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`Kairoo CRM Server running at http://localhost:${PORT}`);
  });
}

// Start server
startServer();

export default app;
